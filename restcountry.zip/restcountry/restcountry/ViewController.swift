//
//  ViewController.swift
//  restcountry
//
//  Created by KAMAR ABBAS SAIYAD on 02/04/23.
//

import UIKit

class ViewController: UIViewController {
    
    var apidata=Array<Any>()

    override func viewDidLoad() {
        super.viewDidLoad()
       getAPIData()
        // Do any additional setup after loading the view.
    }

  func getAPIData()
    
    {
    let apiurl=URL(string: "https://restcountries.com/v2/all")
    
        
        do
        {
           let dt=try Data(contentsOf: apiurl!)
            apidata=try JSONSerialization.jsonObject(with:dt, options: []) as! Array<Any>
            print(apidata)
        }
    catch
        {
        print(error.localizedDescription)
        }
    
    }
}
extension ViewController:UITableViewDataSource,UITableViewDelegate
{
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return apidata.count
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let dict=apidata[indexPath.row] as! Dictionary<String,Any>
    let cell=UITableViewCell(style: .subtitle, reuseIdentifier: nil)
    cell.textLabel?.text=dict["name"] as? String
    cell.detailTextLabel?.text=dict["capital"] as? String
    return cell
    
}
}
